import time

def get_time():
    return time.time()